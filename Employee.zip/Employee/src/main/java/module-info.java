module employee.employee {
    requires javafx.controls;
    requires javafx.fxml;


    opens employee.employee to javafx.fxml;
    exports employee.employee;
}